# 7_Copy3_24_18-3-
Neural Network fitting densities and potentials

Currently working on modifying alphas and data input to prevent overfitting.
